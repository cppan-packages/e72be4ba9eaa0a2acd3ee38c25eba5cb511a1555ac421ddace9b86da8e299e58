/* LICENSE:

MIT License

Copyright (c) 2016 robinwb

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/

/////////////////////////////////////////////////////////////////////

/*
// FOREWORD:
// The goal of this project is to make the most understandable, simplest, header only, noob-friendly, usable JSON parser in less than 500 lines
//
// Pull requests will be accepted if they achieve the following:
// 1) Total code less than 500 lines not including comments
// 2) Neglibible performance penalty
// 3) At least one of the following:
// 		a) improvement in performance
// 		b) improvement in class interface / usage
//	  c) any reasonable improvement not listed here (such as the \u string modifier for unicode)
*/

/////////////////////////////////////////////////////////////////////

/*
// Example usage:

BestJson::JsonValue value; 

value.parse("{\"string\": \"this is a string\", \"boolean\": true, \"boolean2\": false, \
\"int\": 1, \"float\": 1.234, \"array\": [1,2,3,\"string\"], \"object\": {\"test\": 123}}");

cout<< value.dump() <<endl; // {"array": [1, 2, 3, "string"], "boolean": true, "boolean2": false, "float": 1.234, "int": 1, "object": {"test": 123}, "string": "this is a string"}

BestJson tester;
tester.parse( value.dump() );
assert( tester.dump() == value.dump() );

*/

#ifndef BESTJSON_H_
#define BESTJSON_H_

#include <sstream>
#include <fstream>
#include <assert.h>
#include <string>
#include <map>
#include <vector>
#include <limits>

namespace BestJson {
	typedef enum valueType {
		Null,
		Boolean,
		Integer,
		String,
		Array,
		Float,
		Object,
	} ValueType;


	void replace_all(std::string &s, std::string f/*ind*/, std::string r/*eplace*/){ 
		std::string::size_type n = 0;
		while ((n = s.find(f, n)) != std::string::npos) {
			s.replace(n, s.size(), r);
			n += r.size();
		}
	}

	class JsonValue {
	public:
		ValueType type;

		// the possible types
		std::string string;
		int integer;
		bool boolean;
		double double_float;
		std::vector<JsonValue> array;
		std::map<std::string, JsonValue> object;

		JsonValue(){
			type = ValueType::Null;
		}
		JsonValue(ValueType type){
			this->type = type;
		}
		JsonValue(char* c_str){
			type = ValueType::String;
			string = std::string(c_str);
		}
		JsonValue(std::string s){
			type = ValueType::String;
			string = s;
		}
		JsonValue(int i){
			type = ValueType::Integer;
			integer = i;
		}
		JsonValue(double f){
			type = ValueType::Float;
			double_float = f;
		}
		JsonValue(bool b){
			type = ValueType::Boolean;
			boolean = b;
		}
		JsonValue(std::vector<JsonValue> v){
			type = ValueType::Array;
			array = v;
		}
		JsonValue(std::map<std::string, JsonValue> m){
			type = ValueType::Object;
			object = m;
		}
		std::string dump(){
			if (type == ValueType::Object)
				return as_string_object();
			else if (type == ValueType::Array)
				return as_string_array();
			else if (type == ValueType::Float)
				return as_string_float();
			else if (type == ValueType::Integer)
				return as_string_integer();
			else if (type == ValueType::Boolean)
				return as_string_boolean();
			else if (type == ValueType::String)
				return as_string_string();
			else if (type == ValueType::Null)
				return as_string_null();
			else {
				throw std::runtime_error("");
			}
		}
		void parse(std::string json_string){
			// json string must be an object
			assert(json_string.length());
			int i = 0;
			parse_thing_to_end(json_string, i);
		}
		void parse_file(std::string filename){
			std::ifstream t(filename.c_str());
			if (!t.is_open()){
				throw std::runtime_error("Unable to open file: " + filename);
			}
			std::string str((std::istreambuf_iterator<char>(t)), std::istreambuf_iterator<char>());
			parse(str);
		}
	private:
		///////////////////////////////////////////
		// string output
		std::string as_string_object(){
			std::string ret;
			for (auto i = object.begin(); i != object.end(); i++){
				ret += " \"" + i->first + "\": " + i->second.dump() + ",";
			}
			
			if (ret.length() == 0) ret = "{}";
			ret[0] = '{';
			ret[ret.length() - 1] = '}';
			return ret;
		}
		std::string as_string_array(){
			std::string ret;
			for (auto i = array.begin(); i != array.end(); i++){
				ret += " " + i->dump() + ",";
			}
			if (ret.length() == 0) ret = "[]";
			ret[0] = '[';
			ret[ret.length() - 1] = ']';
			return ret;
		}
		std::string as_string_float(){
			std::stringstream ret;
			ret.precision(std::numeric_limits< double >::max_digits10);
			ret << double_float;
			return ret.str();
		}
		std::string as_string_integer(){
			std::stringstream ret;
			ret << integer;
			return ret.str();
		}
		std::string as_string_boolean(){
			if (boolean == false)
				return std::string("false");
			else
				return std::string("true");
		}
		std::string as_string_string(){
			std::string s(string);
			replace_all(s, "\\", "\\\\"); // this must go first
			replace_all(s, "\n", "\\n");
			replace_all(s, "\r", "\\r");
			replace_all(s, "\t", "\\t");
			replace_all(s, "\b", "\\b");
			replace_all(s, "\f", "\\f");
			replace_all(s, "\"", "\\\"");
			return "\"" + s + "\"";
		}
		std::string as_string_null(){
			return std::string("null");
		}

		///////////////////////////////////////////
		// json string parsing
		void skip_whitespace(std::string s, int &i){
			while (s[i] == ' ' || s[i] == '\t' || s[i] == '\r' || s[i] == '\n')
				add_to_i(s, i, 1);
		}
		std::string get_object_key(std::string s, int &i){
			skip_whitespace(s, i);
			assert(s[i] == '"');
			add_to_i(s, i, 1);
			int i_start = i;
			while (s[i] != '"') add_to_i(s, i, 1);
			return s.substr(i_start, i - i_start);
		}
		void parse_object_to_end(std::string s, int &i){
			int i_start = i;
			type = ValueType::Object;
			skip_whitespace(s, i);
			assert(s[i] == '{');
			do {
				add_to_i(s, i, 1);
				skip_whitespace(s, i);
				if (s[i] == '}') break;
				std::string key = get_object_key(s, i);
				while (s[i] != ':'){
					add_to_i(s, i, 1);
				}
				add_to_i(s, i, 1);
				skip_whitespace(s, i);
				object[key] = JsonValue();
				object[key].parse_thing_to_end(s, i);
				skip_whitespace(s, i);
			} while (s[i] == ',');
			assert(s[i] == '}');
			add_to_i(s, i, 1);
		}
		void parse_thing_to_end(std::string s, int &i){
			if (s[i] == '{')
				parse_object_to_end(s, i);
			else if (s[i] == '[')
				parse_array_to_end(s, i);
			else if (s[i] == 'n' || s[i] == 't' || s[i] == 'f')
				parse_other_to_end(s, i);
			else if ((s[i] >= 48 && s[i] <= 57) || s[i] == '-')
				parse_number_to_end(s, i);
			else if (s[i] == '"')
				parse_string_to_end(s, i);
			else {
				throw std::runtime_error("");
			}
		}
		void parse_array_to_end(std::string s, int &i){
			type = ValueType::Array;
			assert(s[i] == '[');
			do {
				add_to_i(s, i, 1);
				skip_whitespace(s, i);
				if (s[i] == ']') break;
				array.push_back(JsonValue());
				array.back().parse_thing_to_end(s, i);
				skip_whitespace(s, i);
			} while (s[i] == ',');
			skip_whitespace(s, i);
			assert(s[i] == ']');
			add_to_i(s, i, 1);
		}
		void parse_number_to_end(std::string s, int &i){
			// either integer or float
			int i_start = i;
			bool is_float = false;
			while (true){
				if (s[i] == '.' || s[i] == 'e' || s[i] == 'E'){
					is_float = true;
				} else if ((s[i] >= 48 && s[i] <= 57) || s[i] == '-' || s[i] == 'e' || s[i] == 'E' || s[i] == '+'){
					// is number, decimal point, negative sign, or scientific notation. Do nothing and continue
				} else {
					break;
				}
				add_to_i(s, i, 1);
			}
			std::stringstream ss;
			ss << s.substr(i_start, i - i_start);
			if (is_float){
				type = ValueType::Float;
				ss >> double_float;
			}
			else {
				type = ValueType::Integer;
				ss >> integer;
			}
			skip_whitespace(s, i);
		}
		bool is_escaped(std::string s, int i){
			bool escaped = false;
			i--;
			while (i >= 0){
				if (s[i] == '\\'){
					escaped = !escaped;
				} else break;
				i--;
			}
			return escaped;
		}
		void parse_string_to_end(std::string s, int &i){
			type = ValueType::String;
			assert(s[i] == '"');
			add_to_i(s, i, 1);
			int i_start = i;
			while (true){
				if (s[i] == '"' && !is_escaped(s, i))
					break;
				add_to_i(s, i, 1);
			}
			string = s.substr(i_start, i - i_start);
			// escape chars here
			replace_all(string, "\\n", "\n");
			replace_all(string, "\\r", "\r");
			replace_all(string, "\\t", "\t");
			replace_all(string, "\\b", "\b");
			replace_all(string, "\\f", "\f");
			replace_all(string, "\\\"", "\"");
			replace_all(string, "\\\\", "\\");
			add_to_i(s, i, 1);
			skip_whitespace(s, i);
		}
		void parse_other_to_end(std::string s, int &i){
			if (s[i] == 't'){
				assert(s.substr(i, 4) == "true");
				type = ValueType::Boolean;
				add_to_i(s, i, 4);
				skip_whitespace(s, i);
				boolean = true;
			}
			else if (s[i] == 'f'){
				assert(s.substr(i, 5) == "false");
				type = ValueType::Boolean;
				add_to_i(s, i, 5);
				skip_whitespace(s, i);
				boolean = false;
			}
			else if (s[i] == 'n'){
				assert(s.substr(i, 4) == "null");
				type = ValueType::Null;
				add_to_i(s, i, 4);
				skip_whitespace(s, i);
			}
		}
		void add_to_i(std::string &s, int &i, int add){
			if ((unsigned)(i + add) > s.length())
				throw std::runtime_error("");
			i += add;
		}
	};
}

#endif // BESTJSON_H_
